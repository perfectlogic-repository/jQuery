<?php
    $json_str = file_get_contents("php://input");
    $json_obj = json_decode($json_str);

    if($json_obj->age > 42 && $json_obj->gender == "female") {
        echo "You got 20% discount";
    } else {
        echo "you got 15% discount";
    }

?>